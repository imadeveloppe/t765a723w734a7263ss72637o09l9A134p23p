///////////////***** Global Varibles ******/////////////////////////
window.onerror = function(message, url, lineNumber) {
    //alert("Error: "+message+" in "+url+" at line "+lineNumber);
} 

var APPNAME = "com.ionicframework.app538533";
var urlApi = "http://dev.tawassolapp.com/";
 
function checkConnection() {
    
    var networkState = navigator.connection.type;
 
    var states = {};
    states[Connection.UNKNOWN]  = 'Unknown connection';
    states[Connection.ETHERNET] = 'Ethernet connection';
    states[Connection.WIFI]     = 'WiFi connection';
    states[Connection.CELL_2G]  = 'Cell 2G connection';
    states[Connection.CELL_3G]  = 'Cell 3G connection';
    states[Connection.CELL_4G]  = 'Cell 4G connection';
    states[Connection.CELL]     = 'Cell generic connection';
    states[Connection.NONE]     = 'Pas de connexion internet';

    return {
    	type : networkState,
    	value : states[networkState]
    }
}
// localStorage.setItem('adresseMac','08:EE:8B:BB:80:8E');  
if( !localStorage.getItem('customBackground') ){
	localStorage.setItem('customBackground',"url(img/bg/bg1.jpeg)"); 
}
if( !localStorage.getItem('fileDownloaded') ){
	var obj = {};
	localStorage.setItem('fileDownloaded', JSON.stringify(obj));
	localStorage.setItem('logosDownloaded', JSON.stringify(obj));
	localStorage.setItem('login',"false")
} 

////////////////////////////////////////////////////////////////////
angular.module('app.controllers', [])

.controller('NotifCtrl', ['$scope', "$state", '$stateParams','$rootScope','$AjaxQuery', '$cordovaBadge', '$alert', '$cordovaLocalNotification', '$interval', 
function ($scope, $state, $stateParams, $rootScope, $AjaxQuery, $cordovaBadge, $alert, $cordovaLocalNotification, $interval) {  

	$rootScope.$on("checkConnectionInternet", function(){
           $scope.checkConnectionInternet();	
    }); 
    $rootScope.$on("UpdateBadge", function(){
           $scope.UpdateBadge();
    });
    $scope.checkConnectionInternet = function () {
    	var network = checkConnection(); 
		$rootScope.NetworkTrue = ( network.type == "none" ) ? false : true; 
    } 
	$scope.UpdateBadge = function UpdateBadge() {
		var notifBadge =  parseInt( localStorage.getItem('notif') );
		if(notifBadge <= 0){
			localStorage.setItem('notif', 0);
			notifBadge = 0;
		}   
		$rootScope.notifBagde  = notifBadge;  
		if( notifBadge ){
			//cordova.plugins.notification.badge.set( notifBadge );
		} else{
			//cordova.plugins.notification.badge.set( 0 );
		}
		cordova.plugins.notification.badge.set( 0 );

	}
	$scope.UpdateBadge();

}])
 




.controller('homeCtrl', ['$scope', '$stateParams','$AjaxQuery','$state','$interval','$rootScope','$alert','$cordovaLocalNotification', 
function ($scope, $stateParams, $AjaxQuery, $state, $interval, $rootScope, $alert, $cordovaLocalNotification ) { 

	function onDeviceReady() { 
		var element = document.getElementById('deviceProperties'); 


		if( localStorage.getItem('login') == "false" || localStorage.getItem('login') == "" ){ 
			///////////////////////////////// Test Connexion ///////////////////////////////////////////////
			var network = checkConnection(); 
			$rootScope.NetworkTrue = ( network.type == "none" ) ? false : true; 
			////////////////////////////////////////////////////////////////////////////////////////////////
			window.plugins.uniqueDeviceID.get(function (adresseMac){  
			 		//console.log("adresseMac ",adresseMac )
		            localStorage.setItem('adresseMac',adresseMac); 
		            // localStorage.setItem('adresseMac','08:EE:8B:BB:80:8E'); 
		            window.FirebasePlugin.getToken(function(token) { 
			            var reqData ={ 
							 adresseMac   : localStorage.getItem('adresseMac'),
							 token	: token,
							 appname: APPNAME
						} 
						if( $rootScope.NetworkTrue ){ 
							$AjaxQuery.post('login', reqData ).success(function(data) {  
						 		if( data.login == 'false' ){ 
						 			$state.go('register');
						 		}else{
						 			localStorage.setItem('idClient',data.idClient);
						 			localStorage.setItem('state',data.state);
						 			localStorage.setItem('login', "true")



						 			$AjaxQuery.post('getStudents', reqData ).success(function(data) {
										localStorage.setItem('students', JSON.stringify(data));
										$scope.students = data;
									})

									$AjaxQuery.post('getParentName', reqData ).success(function(data) {
										localStorage.setItem('Parent', JSON.stringify(data));
										$scope.Parent = data;
									}) 


						 			$state.go('tabs.messages');
						 			$interval(function () { 
										$rootScope.$emit("checkConnectionInternet", {}); 
									},3000)  
			 
						 		}
							})
						}else{
							alert( "Pas de connexion internet" );
							onDeviceReady();
						}
					}, function(error) {
				        console.error("FirebasePlugin ",error);
				    });

		        },function(fail) { 
		            alert(fail);
		        }
		    ); 
		}else{ 
			$state.go('tabs.messages'); 
			$interval(function () {  
				$rootScope.$emit("checkConnectionInternet", {}); 
			},3000); 

		}
	}
	$scope.$on('$ionicView.beforeEnter', function() {
		document.addEventListener('deviceready', onDeviceReady, false);
	}) 
	// document.addEventListener('deviceready', onDeviceReady, false); 
	 
}])











.controller('messagesCtrl', ['$scope','$cordovaFileTransfer','$state', '$stateParams','$AjaxQuery','$rootScope','$ionicPopover', '$cordovaLocalNotification','$ionicScrollDelegate', 
function ($scope,$cordovaFileTransfer, $state, $stateParams, $AjaxQuery, $rootScope, $ionicPopover, $cordovaLocalNotification, $ionicScrollDelegate ) { 


	$scope.urlLogos = urlApi+"assets/upload/logos/";
	$scope.$on('$ionicView.beforeEnter', function() {
        $scope.GetMessages() // Call Messages
        $scope.EleveSelected = {}; 
        $scope.ElevesInApp();
    });
	$scope.dataFilterEleves = [];
 	//$rootScope.NetworkTrue = true;
 	$scope.filterEleve = false;
 	$cordovaLocalNotification.cancelAll()

 	$rootScope.$on("CallMessages", function(){
           $scope.GetMessages();
    });  

 	$scope.RefreshMessages = function () {
 		setTimeout(function () {
 			$scope.GetMessages();
 		},1000)
 	}

 	$scope.directionality = function ( str ) {
		if( str.search('dir="rtl"') >= 0 ){
			return "rtl";
		}else{
			return "ltr";
		}
	}
    $scope.dataFilterEleves =[]

    var unique = function(origArr) {
	    var newArr = [],
	        origLen = origArr.length,
	        found, x, y;

	    for (x = 0; x < origLen; x++) {
	        found = undefined;
	        for (y = 0; y < newArr.length; y++) {
	            if (origArr[x] === newArr[y]) {
	                found = true;
	                break;
	            }
	        }
	        if (!found) {
	            newArr.push(origArr[x]);
	        }
	    }
	    return newArr;
	}

    $scope.showFilterEleves = function () {
    	
    	setTimeout(function () {
    		if( !$scope.filterEleve ){
	    		var dataFilterEleves = [];
	    		$scope.dataFilterEleves = []; 
	    		$scope.EleveSelected.value = "all";
	    		angular.forEach($scope.Messages, function (item, key) {
					if(item.name){ 
						dataFilterEleves.push(item.name)
					}
				})
				setTimeout(function () {
					$scope.dataFilterEleves = unique(dataFilterEleves)
				})
				
				
	    	} 
	    	$scope.filterEleve = !$scope.filterEleve;
	    	$scope.isFilter = !$scope.isFilter;

	    	if( !$scope.isFilter ){
	    		$scope.$apply(function () {
	    			$scope.Messages = JSON.parse(localStorage.getItem('data'));
	    		})
	    	}
    	})
    }  

    $scope.ElevesInApp = function () {
    	var dataFilterEleves = []; 
    	angular.forEach($scope.Messages, function (item, key) {
			if(item.name){ 
				dataFilterEleves.push(item.name)
			}
		})
		setTimeout(function () {
			$scope.dataFilterEleves = unique(dataFilterEleves)
		})
    }

    $scope.isJson = function( str ) {
	    try {
	        JSON.parse(str);
	    } catch (e) {
	        return false;
	    }
	    return true;
	}
	$scope.GetMessages = function() {
		$scope.Messages = JSON.parse(localStorage.getItem('data'));  

		if( $rootScope.NetworkTrue ){  
			window.FirebasePlugin.getToken(function(token) { 
				var reqData ={
					token: token,
					appname: APPNAME
				} 
				$AjaxQuery.post('messages/'+localStorage.getItem('adresseMac'), reqData ).success(function(data) {

				$scope.$broadcast('scroll.refreshComplete');

				if( data=="NoStudents" ){
					$state.go("blocked");
					localStorage.setItem('notif', 0 );
					$rootScope.$emit("UpdateBadge", {});
				}else{

					if( $scope.isJson(JSON.stringify(data)) ){

						localStorage.setItem('data',JSON.stringify(data))
						$scope.Messages = data;
						$scope.ElevesInApp();

						$scope.active = 0;
						var nbrMessagesReaded = 0;
						var nbrMessagesNotRead = 0;
						angular.forEach(data, function (message, key) {
							if( message.vu == 'true' ){
								nbrMessagesReaded++;
							}else{
								nbrMessagesNotRead++;
							}
						})
						localStorage.setItem('totalMessages', nbrMessagesReaded + nbrMessagesNotRead ); 
						localStorage.setItem('messageNotReaded', nbrMessagesNotRead ); 
						if( nbrMessagesNotRead > 0 ){
							//console.log( nbrMessagesNotRead )
							localStorage.setItem('notif', nbrMessagesNotRead );
							$rootScope.$emit("UpdateBadge", {});
						}else{
							localStorage.setItem('notif', 0 );
							$rootScope.$emit("UpdateBadge", {});
						}
					}
				} 
				}) 
			}, function(error) {
		        console.error("FirebasePlugin ",error);
		    });

		}else{
			setTimeout(function () {
				$scope.GetMessages();
			}, 500)
		}
	} 

	//////////////////// Filter 
	$scope.active = 0;
	
	$scope.filter = function(arg, active) {  
		$scope.active = active;
		$ionicScrollDelegate.scrollTop();
		if(arg == "all"){ 
			$scope.filterEleve = false;
			if($scope.isFilter){
				$scope.Messages = JSON.parse(localStorage.getItem('data'));
			}else if( $scope.PreventActive != 0 ){ 
				$('.message-item').removeClass("hide");
			} 
			$scope.PreventActive = 0;
		} 
		if(arg == "from-prof"){
			if( $scope.PreventActive != 1 ){   
				$('.message-item').not($('.message-item.from-prof')).addClass("hide");
			}
			$('.from-prof').removeClass("hide");
			$scope.PreventActive = 1;
			
		} 
		if(arg == "from-admin"){ 
			if( $scope.PreventActive != 2 ){ 
				$('.message-item').not($('.message-item.from-admin')).addClass("hide");
			}
			$('.from-admin').removeClass("hide");
			$scope.PreventActive = 2;
		}  
		$scope.isFilter = false;
	}   
	 
	$scope.filterByEleve = function () { 
		var data = JSON.parse(localStorage.getItem('data'));
		var newData = [];   
		if( $scope.EleveSelected.value=="all"){ 
			$scope.Messages = data; 
		}else{
			angular.forEach( data, function(message, key) {
				if( message.name == $scope.EleveSelected.value ){
					newData.push( message );
				}
			}) 
			$scope.Messages = newData;
			setTimeout(function () { 
				$ionicScrollDelegate.scrollTop(true);
			})
		} 
		setTimeout(function () { 
			$ionicScrollDelegate.scrollTop(true);
		})
	} 
	///////////////////////////

	//// pop hover 
	$scope.openPopover = function ($event, ecole, logo) {

		///////////////////////////////// Test Connexion ///////////////////////////////////////////////
		var network = checkConnection(); 
		$rootScope.NetworkTrue = ( network.type == "none" ) ? false : true; 
		////////////////////////////////////////////////////////////////////////////////////////////////

		var serverUrl = urlApi+"assets/upload/";
		var SmallLogo = urlApi+"assets/upload/logos/";
		if( ionic.Platform.isIOS() ){
      		$scope.ExternalPath = cordova.file.documentsDirectory;
      	}else{
      		// $scope.ExternalPath = "file:///data/data/com.imad.tawassolapp/files/";
      		$scope.ExternalPath = cordova.file.externalDataDirectory; 
      	} 

      	var downloadedLogos = JSON.parse( localStorage.getItem('logosDownloaded') ); 
   		var findVal = 0; 
   		angular.forEach(downloadedLogos,function (key, value) {

   			if ( logo == parseInt( value ) ) { 
	   			findVal++;
	   			console.log("downloaded");
	   		} 
   		}) 
   		$scope.downloaded = ( findVal > 0 ) ? true : false;
 

		if( logo == "img/nologo.png"){
			var template = '<ion-popover-view><ion-header-bar> <h1 class="title">'+ecole+'</h1> </ion-header-bar> <div class="ion-content"><img width="100%" src="'+logo+'"></div></ion-popover-view>';
		}else{
			if( $scope.downloaded ){
				var template = '<ion-popover-view><ion-header-bar> <h1 class="title">'+ecole+'</h1> </ion-header-bar> <div class="ion-content"><img width="100%" src="'+$scope.ExternalPath+logo+'"></div></ion-popover-view>';
			}else if( !$scope.downloaded && $rootScope.NetworkTrue ){
				$scope.downloadImage( logo );
				var template = '<ion-popover-view><ion-header-bar> <h1 class="title">'+ecole+'</h1> </ion-header-bar> <div class="ion-content"><img width="100%" src="'+serverUrl+logo+'"></div></ion-popover-view>';
			} 
			else if(!$scope.downloaded && !$rootScope.NetworkTrue){
				var template = '<ion-popover-view><ion-header-bar> <h1 class="title">'+ecole+'</h1> </ion-header-bar> <div class="ion-content"><img width="100%" src="'+SmallLogo+logo+'"></div></ion-popover-view>';
			}
		} 
		
		$scope.popover = $ionicPopover.fromTemplate(template, {
		    scope: $scope
		}); 
		$scope.popover.show($event);
	}
	$scope.downloadImage = function (logo) {

	    	$scope.downloading = true; 
	    	var urlImage = urlApi+"assets/upload/"+logo;  
	      	var targetPath = $scope.ExternalPath+logo; 

		    $cordovaFileTransfer.download(urlImage, targetPath, {}, true)
		    .then(function(result) { 

			    var JSONDownloadedLogos = JSON.parse( localStorage.getItem('logosDownloaded') );
			    //console.log("Before",JSONDownloadedLogos)
			    JSONDownloadedLogos[logo] = logo;
			    //console.log("After",JSONDownloadedLogos)
				localStorage.setItem('logosDownloaded', JSON.stringify( JSONDownloadedLogos ) );

		    },function(err) {  

		        $scope.downloading = false; 
		        $scope.downloaded = false; 
		        
		    },function(progress) { 
		    	$scope.progressing = (progress.loaded / progress.total) * 100; 
		    });
	    }

	

	
}])




















.controller('messageCtrl', ['$scope','$sce', '$loader','$cordovaToast', '$stateParams','$rootScope','$AjaxQuery','$ionicModal','$timeout','$cordovaFileTransfer','$cordovaFile', 
function ($scope,$sce,$loader,$cordovaToast, $stateParams,  $rootScope, $AjaxQuery, $ionicModal, $timeout, $cordovaFileTransfer, $cordovaFile) {   
		


	if( $stateParams.idMessage != null || localStorage.getItem('idMessage') ){  
		 
		$scope.filePath = urlApi+"assets/upload/thumbs/";
		///////////////////////////////// Test Connexion ///////////////////////////////////////////////
		var network = checkConnection(); 
		$rootScope.NetworkTrue = ( network.type == "none" ) ? false : true; 
		////////////////////////////////////////////////////////////////////////////////////////////////

		if( ionic.Platform.isIOS() ){
      		// $scope.ExternalPath = cordova.file.documentsDirectory;
      		// $scope.ExternalPath = cordova.file.applicationStorageDirectory
      		$scope.ExternalPath = cordova.file.cacheDirectory
      	}else{
      		// $scope.ExternalPath = "file:///data/data/com.imad.tawassolapp/files/";
      		$scope.ExternalPath = cordova.file.externalDataDirectory; 
      	}


		$scope.$on('$ionicView.beforeEnter', function() {
	        $scope.customBackground = localStorage.getItem('customBackground'); 
	        //$scope.fileDownloaded = false;
	    });
	    $scope.trustAsHtml = function(string) {
		    return $sce.trustAsHtml(string);
		};
		$scope.directionality = function ( str ) {
			if( str.search('dir="rtl"') >= 0 ){
				return "rtl";
			}else{
				return "ltr";
			}
		}
	    $scope.DownloadFile = function(fileName) {   
	    	
	      	var urlFile = urlApi+"assets/upload/"+fileName; 

	      	var targetPath = $scope.ExternalPath+fileName;
	      	
		    var trustHosts = true;
		    var options = {}; 


		    $cordovaFileTransfer.download(urlFile, targetPath, options, trustHosts)
		    .then(function(result) {  

		    	$scope.targetPath = targetPath;  
		        $scope.downloadFileToGallery( targetPath );
		        $scope.downloading = false; 
		        $scope.downloaded = true;  

		    },function(err) { 
		        //$scope.dataError = err;
		    },function(progress) {
		        // $cordovaToast.showLongCenter( parseInt( (progress.loaded / progress.total) * 100  ) )
		    }); 

	    }
		$scope.downloadImage = function (fileName) {

	    	$scope.downloading = true; 
	    	var urlImage = urlApi+"assets/upload/android/"+fileName;  
	      	var targetPath = $scope.ExternalPath+fileName; 

	      	

		    $cordovaFileTransfer.download(urlImage, targetPath, {}, true)
		    .then(function(result) {    
		    	console.log("Download Image result", result);
		    	$scope.downloading = false; 
		        $scope.downloaded = true;  

		        $scope.targetPath = targetPath; 
		        $scope.downloadFileToGallery();
		        

		    },function(err) {  
		    	console.log("Download Image err", err);
		        $scope.downloading = false; 
		        $scope.downloaded = false; 
		        
		    },function(progress) { 
		    	$scope.progressing = (progress.loaded / progress.total) * 100; 
		    });
	    }

	    
		$scope.downloaded = true;

		var newData = JSON.parse(localStorage.getItem('data'));
	 	angular.forEach( newData, function(message, key) { 
	 		
		   if( message.idMessage == $stateParams.idMessage && message.idClient == $stateParams.idClient ){  
		   		//console.log("idMessage", message.idMessage) 
		   		$scope.Message = message; 
		   		////// If downloaded file
		   		//console.log( localStorage.getItem('fileDownloaded') )
		   		
	   			var downloadedFiles = JSON.parse( localStorage.getItem('fileDownloaded') ); 
		   		var findVal = 0;
		   		angular.forEach(downloadedFiles,function (key, value) {

		   			if ( message.idMessage == parseInt( value ) ) { 
			   			findVal++;
			   		} 
		   		})  
		   		setTimeout(function () {
		   			if( findVal > 0 ){
		   			$scope.downloaded = true; 
			   		}else{
			   			$scope.downloaded = false;
			   			console.log( message.typeFile )
			   			if( message.typeFile != 'notImage' ){
			   				if( $rootScope.NetworkTrue ){
				   				$scope.downloadImage( message.file );

				   				console.log( "downloadImage" )
				   			} 
			   			}else{ 
			   				if( $rootScope.NetworkTrue ){
			   					$scope.DownloadFile( message.file );
			   					$scope.downloading = true; 
			        			$scope.downloaded = false;  

			        			//console.log( DownloadFile )
			   				}
			   			} 
			   		}

		   		})
		   		////////////////////////// 
		   		if( message.vu == 'false' ){ 
		   			if( $rootScope.NetworkTrue ){ 
			   			$AjaxQuery.post('addVuToMessage/'+message.idMessage+'/'+message.idClient, {} ).success(function(data) {

							// localStorage.setItem('notif', (parseInt(localStorage.getItem('notif')) - 1) );  
							// $rootScope.$emit("UpdateBadge", {}); 
						}) 
					}
		   		}
		   		
		   		
		   }
		});  
	 	////////////////********** Open Modal **************//////////////////
	 	$ionicModal.fromTemplateUrl('image-modal.html', {
	      scope: $scope,
	      animation: 'slide-in-up'
	    }).then(function(modal) {
	      $scope.modal = modal;
	    });

	    $scope.openModal = function() {
	      $scope.modal.show();
	    };

	    $scope.closeModal = function() {
	      $scope.modal.hide();
	    };

	    //Cleanup the modal when we're done with it!
	    $scope.$on('$destroy', function() {
	      $scope.modal.remove();
	    });
	    // Execute action on hide modal
	    $scope.$on('modal.hide', function() {
	      // Execute action
	    });
	    // Execute action on remove modal
	    $scope.$on('modal.removed', function() {
	      // Execute action
	    });
	    $scope.$on('modal.shown', function() {
	      console.log('Modal is shown!');
	    });
	 
	    $scope.ShowBtnDowload = false;  
	    /////////////////////////////////// download image from server to locale ////////////////////////////////////////
	    $scope.showImage = function(fileName) { 
	        
	        $scope.imageSrc = $scope.ExternalPath+fileName;
	        $scope.openModal(); 

	    }  
		$scope.openLocalUrl = function ( file ) { 
	    	path = $scope.ExternalPath;
			
			if( ionic.Platform.isIOS() ){
      			window.open( path+file,'_blank','EnableViewPortScale=yes,location=no');
	      	}else{ 
	      		window.open( path+file,'_system','location=yes');
	      	}
		}

		$scope.openUrl = function ( file ) { 
	    	path = $scope.filePath;
			window.open( path+file,'_system','location=yes');
			console.log("openUrl", path+file)
		}
 
	    /////////////////////////////////// Move image to gallery ////////////////////////////////////////

	    $scope.downloadFileToGallery = function () { 

	    	if( !$scope.fileDownloaded ){
	    		$scope.fileDownloaded = true;
	    		var JSONDownloadedFIle = JSON.parse( localStorage.getItem('fileDownloaded') ); 
		    	JSONDownloadedFIle[$scope.Message.idMessage] = $scope.Message.idMessage;
		    	localStorage.setItem('fileDownloaded', JSON.stringify( JSONDownloadedFIle ) );

		    	window.cordova.plugins.imagesaver.saveImageToGallery($scope.targetPath, onSaveImageSuccess, onSaveImageError); 
				function onSaveImageSuccess(success) {
				  $scope.fileDownloaded = true;
				} 
				function onSaveImageError(error) { 
					console.log("Save Image error", error);
					$scope.fileDownloaded = false;
				}
	    	}
	    	
	    }


	    $scope.rotateValue = 0;
	    $scope.rotateImage = function () {
	    	$scope.rotateValue += 90;
	    }
	    ////////////////************************//////////////////
	}
 
	
}])



















.controller('settingCtrl', ['$scope','$rootScope', '$stateParams','$AjaxQuery', 
function ($scope,$rootScope, $stateParams,$AjaxQuery) {
	// console.log("Parent ",localStorage.getItem('Parent'))
	// console.log("students ",localStorage.getItem('students'))
	var reqData ={ 
		 adresseMac   : localStorage.getItem('adresseMac'),
		 appname   : APPNAME
	}  
	if( localStorage.getItem('Parent') != '' ){
		$scope.Parent = JSON.parse(localStorage.getItem('Parent'));
	}else{
		$scope.Parent = {
			nom: ""
		}
	} 
	if( $rootScope.NetworkTrue ){ 
		$AjaxQuery.post('getParentName', reqData ).success(function(data) {
			localStorage.setItem('Parent', JSON.stringify(data));
			$scope.Parent = data;
		})
	}

	$scope.gotoDownloadFolder = function () {

		startApp.set({ 
		    "package":"com.sec.android.app.myfiles",
		    "uri":"/storage/emulated/0/TawassolApp/"
		}).start() 
	}

}])



















.controller('studentsCtrl', ['$scope','$rootScope', '$stateParams','$AjaxQuery','$alert', 
function ($scope,$rootScope, $stateParams,$AjaxQuery,$alert) {
	var reqData ={ 
		 adresseMac   : localStorage.getItem('adresseMac'),
		 appname: APPNAME
	} 
	$rootScope.students = JSON.parse(localStorage.getItem('students'));
	if( $rootScope.NetworkTrue ){ 
		$AjaxQuery.post('getStudents', reqData ).success(function(data) {
			localStorage.setItem('students', JSON.stringify(data));
			$rootScope.students = data;
		})
	}
	// $scope.showState = function (name, state) {
	// 	if(state==true){
	// 		$alert.success('Le compte de '+name+' est validé',3000)
	// 	}else{
	// 		$alert.error('Le compte de '+name+' est désactivé. Contacter l\'administration')
	// 	}
	// }
}])




.controller('addStudentCtrl', ['$scope','$rootScope', '$stateParams','$loader','$AjaxQuery','$alert','$state','$location', '$ionicModal', 
function ($scope,$rootScope, $stateParams, $loader, $AjaxQuery,$alert,$state, $location, $ionicModal) {

	$scope.code = '';
	if(localStorage.getItem('Parent')){
		var Parent =  JSON.parse(localStorage.getItem('Parent'))
		$scope.nomParent = Parent.nom; 
		$scope.telParent = Parent.telParent; 
	}else{
		$scope.nomParent = "";
		$scope.telParent = "";
	}
	 

	$scope.codeValide = false;
	$scope.verifCode = function verifCode() { 

		var code = $scope.code;
		if( code.length >= 6 ){
			$loader(true); 
			var reqData = {
				appname: APPNAME
			};
			$rootScope.NetworkTrue = true
			if( $rootScope.NetworkTrue ){ 
				$AjaxQuery.post('verifCode/'+code, reqData).success(function (data) {
					console.log(data)
					$loader(false);
					if(data.success == 1){    
						$scope.codeValide = true;  
						$scope.nomEcole = data.info.nomEcole;
						$scope.photoEcole = data.info.photoEcole;
						$scope.fname = data.info.fname;
						$scope.lname = data.info.lname;
						$scope.niveau = data.info.niveau;
						$scope.classe = data.info.classe;
						$scope.groupe = data.info.groupe;
						$scope.idClient = data.info.idClient;
						$scope.cgu = true;
						$scope.pub = true;
			        }else{
			          $alert.error('Code invalide')
			        }
				})
			}else{
				alert( "Pas de connexion internet" )
			} 
		}
	}
 	$scope.changeCode = function changeCode() {
		$scope.codeValide = false;
	}

	$rootScope.$on("CallMessages", function(){
           $scope.codeValide = false;
    });

	$scope.OnchangeClasse = function() {
		 $scope.nbrGroupeByClasse = [];    
		 for (var i = 0; i < $scope.nbrClassesByNiveau[parseInt($scope.classe) - 1]; i++) {  
        	$scope.nbrGroupeByClasse.push($scope.intituleGroupe[i]) 
		 }   
		 $scope.groupe = "";  
	}
	$scope.OnchangeNiveau = function() {
		var code = $scope.code;
		var niveau = parseInt($scope.niveau);
		if( $rootScope.NetworkTrue ){ 
			$AjaxQuery.post("getClassesByCode/"+code+"/"+niveau, {}).success(function (data) {
	            $scope.intituleClasse = []
	        	angular.forEach(data.intituleClasse, function (value, key) {
	        		var array = {
	        			id : key+1,
	        			name : value
	        		} 
	        		if( data.nbrClassesByNiveau[key] > 0 ){
		        		$scope.intituleClasse.push(array)
		        	}
	        	})
	        	$scope.intituleGroupe = []
	        	angular.forEach(data.intituleGroupe, function (value, key) {
	        		var array = {
	        			id : key+1,
	        			name : value
	        		}  
	        		$scope.intituleGroupe.push(array)
	        	}) 
	        	$scope.classe = ""; 

				$scope.nbrGroupeByClasse = [];    
				for (var i = 0; i < data.nbrClassesByNiveau[0]; i++) { 
		        	$scope.nbrGroupeByClasse.push($scope.intituleGroupe[i]) 
				}    
				$scope.groupe = "";
				$scope.nbrClassesByNiveau = data.nbrClassesByNiveau;
	        })
        }else{
			alert( "Pas de connexion internet" )
		} 
	}
	function validate() {

		var  nomParent = telParent = cgu = false; 
 

		if($scope.nomParent){ 
			nomParent=true;
		}else{
			$alert.error('Veuillez saisir le nom du parent');
			return false
		} 

		if($scope.telParent){ 
			if($scope.telParent.length >= 10){
				telParent=true;
			}else{
				$alert.error('Veuillez saisir un numéro de téléphone valide');
				return false
			}

		}else{
			$alert.error('Veuillez saisir votre numéro de téléphone');
			return false
		} 

		if($scope.cgu){ 
			cgu=true;
		}else{
			$alert.error("Veuillez lire et accepter les conditions générales d'utilisation");
			return false
		} 

		if(nomParent && telParent && cgu){ 
			return true
		}else{
			return false
		} 

	}
	
	$scope.addStudent = function addStudent() {   
		if( validate() ){ 
			$scope.openModal(); 
		}
	}
	$scope.sendData = function () {
		$loader(true); 
		if( $rootScope.NetworkTrue ){   
		window.FirebasePlugin.getToken(function(token) { 
			var reqData ={ 
				 adresseMac   : localStorage.getItem('adresseMac'),
				 idClient   	  : $scope.idClient,  
				 nomParent    : $scope.nomParent,
				 telParent    : $scope.telParent,
				 token    	  : token,
				 appname      : APPNAME,
				 pub		  : ($scope.pub) ? 1 : 0
			}  
			console.log(reqData)
			$AjaxQuery.post('insertClient', reqData ).success(function(data) {
					$scope.closeModal();
					$loader(false);
					if( data.success == 1 ){   
				        if( $location.path() == "/register" ){
				        	$alert.success( data.message,4000);
				        	setTimeout(function () {
								$state.go('tabs.messages');
							},4000)

						}else{
							$alert.success('L\'élève est bien ajouté',4000);
							setTimeout(function () {
								$state.go('tabs.students');
							},4000)
						} 
				    }else{
				    	$alert.error( data.message )
				    } 
				})
		}, function(error) {
	        console.error("FirebasePlugin ",error);
	    }); 
				

		}else{
			alert( "Pas de connexion internet" )
		}
	}

	$ionicModal.fromTemplateUrl('templates/modal-register.html', {
		scope: $scope,
		animation: 'slide-in-up'
	}).then(function(modal) {
		$scope.modal = modal;
	});
	$scope.openModal = function() {
		$scope.modal.show();
	};
	$scope.closeModal = function() {
		$scope.modal.hide();
	}; 




	$ionicModal.fromTemplateUrl('templates/modal-cgu.html', {
		scope: $scope,
		animation: 'slide-in-up'
	}).then(function(modal) {
		$scope.ModalCGU = modal;
	});
	$scope.openModalCGU = function() {
		$scope.ModalCGU.show();
	};
	$scope.closeModalCGU = function() {
		$scope.ModalCGU.hide();
	}; 



	
}])
















.controller('aboutCtrl', ['$scope', '$stateParams', 
function ($scope, $stateParams) {


}])

.controller('backgroundCtrl', ['$scope', '$stateParams','$loader','$cordovaToast', 
function ($scope, $rootScope, $loader, $cordovaToast) {  

	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd
	} 

	if(mm<10) {
	    mm='0'+mm
	} 

	$scope.today = dd+'/'+mm+'/'+yyyy;

	$scope.$on('$ionicView.beforeEnter', function() {  
		$scope.data = [];
		for (var i = 1; i <= 6; i++) {
			$scope.data.push( 'url(img/bg/bg'+i+'.jpeg)' )
		}
		$scope.customBackground = $scope.data[0];
		$scope.index = 0;
	});
	$scope.changeBG = function (index) { 
		$scope.hideSwip = true;
		$scope.customBackground = $scope.data[index]; 
		$scope.index = index;
	}
	$scope.appliqueBackground = function (index) {
		//console.log($scope.data);
		localStorage.setItem('customBackground', $scope.data[$scope.index]);
		$cordovaToast.showShortCenter( "Arrière plan défini." );
	}
}])


.controller('blockedCtrl', ['$scope', '$stateParams', "$ionicHistory",
function ($scope, $stateParams, $ionicHistory) { 
	localStorage.setItem('fileDownloaded', "[]");
	localStorage.setItem('logosDownloaded', "[]");
	localStorage.setItem('login',"false")
	localStorage.setItem('idClient',"");
	localStorage.setItem('state',"");
	localStorage.setItem('login', "false")
	localStorage.setItem('students', "[]")
	localStorage.setItem('Parent', "")
	localStorage.setItem('data',"[]")
	$ionicHistory.clearHistory();
    $ionicHistory.clearCache();
}])


.controller('profileStudentCtrl', ['$scope', '$rootScope', '$stateParams', '$cordovaActionSheet', '$cordovaCamera', '$cordovaImagePicker', '$jrCrop', '$AjaxQuery', 
function ($scope, $rootScope, $stateParams, $cordovaActionSheet, $cordovaCamera, $cordovaImagePicker, $jrCrop, $AjaxQuery) {
	angular.forEach($rootScope.students, function (student, key) {
		if( student.idClient ==  $stateParams.idClient){
			$scope.student = student;
		}
	})



	function toDataUrl(src, callback, outputFormat) {
	  var img = new Image();
	  img.crossOrigin = 'Anonymous';
	  img.onload = function() {
	    var canvas = document.createElement('CANVAS');
	    var ctx = canvas.getContext('2d');
	    var dataURL;
	    canvas.height = this.height;
	    canvas.width = this.width;
	    ctx.drawImage(this, 0, 0);
	    dataURL = canvas.toDataURL(outputFormat);
	    callback(dataURL);
	  };
	  img.src = src;
	  if (img.complete || img.complete === undefined) {
	    img.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";
	    img.src = src;
	  }
	}
  
	$scope.ChooserFile = function () {
		var options = {
		    title: 'Choisir une option',
		    buttonLabels: ['Appareil photo', 'Gallerie'],
		    addCancelButtonWithLabel: 'Annuler',
		    androidEnableCancelButton : true,
		    winphoneEnableCancelButton : true
		 };
		$cordovaActionSheet.show(options)
	    .then(function(btnIndex) {
	    	console.log(btnIndex)
	        if(btnIndex == 1){
	        	$scope.OpenCamera();
	        }else if(btnIndex == 2){
	        	$scope.OpenGallery();
	        }
	    });

	}
	$scope.OpenCamera = function () {  
		
		if( ionic.Platform.isIOS() ){ 
		    var options = {
		      	destinationType: navigator.camera.DestinationType.DATA_URL,
		        targetHeight: 400,
		        targetWidth: 400,
		        encodingType: navigator.camera.EncodingType.PNG,
	            quality: 85  
		    };	
		}else{
	    	var options = {
		      quality: 85,
		      destinationType: Camera.DestinationType.DATA_URL,
		      sourceType: Camera.PictureSourceType.CAMERA,
		      allowEdit: false,
		      encodingType: Camera.EncodingType.JPEG,
		      targetWidth: 400,
		      // targetHeight: 400,
		      popoverOptions: CameraPopoverOptions,
		      saveToPhotoAlbum: false,
			  correctOrientation:true
		    };
	    }

	    $cordovaCamera.getPicture(options).then(function(imageData) {    
	      	$jrCrop.crop({
                url: "data:image/jpeg;base64," + imageData,
                circle: true,
                width: 250,
                height: 250
            }).then(function(canvas) { 
                $scope.student.photo = canvas.toDataURL();  
                $scope.sendPhoto();
            }, function() { 
            });
	    }, function(err) {
	      // error
	    });
	}
	$scope.OpenGallery = function () {   

	    if( ionic.Platform.isIOS() ){ 
			var options = {
			 	maximumImagesCount: 1,
			    width: 400,
			    height: 400,
			    quality: 100
		 	};
			$cordovaImagePicker.getPictures(options)
		    .then(function (results) {
		     
		      	toDataUrl( results[0], function(base64Img) {
				  	$jrCrop.crop({
		                url: base64Img,
		                circle: true,
		                width: 250,
		                height: 250
		            }).then(function(canvas) { 
		                $scope.student.photo = canvas.toDataURL();
		                $scope.sendPhoto();  
		            }, function() { 
		            });
				}); 
 
		    }, function(error) {
		       
		    });
		}else{   
		 	var options = {	
				sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY,
                destinationType: navigator.camera.DestinationType.DATA_URL,
                maximumImagesCount: 1, 
			   	quality: 100,
			   	width: 300,
		        height: 300,
			   	correctOrientation:true

			}
			$cordovaCamera.getPicture(options).then(function(imageData) { 
		      var base64Img = "data:image/jpeg;base64," + imageData; 
		      $jrCrop.crop({
	                url: base64Img,
	                circle: true,
	                width: 250,
	                height: 250
	            }).then(function(canvas) { 
	                $scope.student.photo = canvas.toDataURL();
	                $scope.sendPhoto();  
	            }, function() { 
	            });
		    }, function(err) {
		      // error
		    });
	 	}
	}

	$scope.removePhoto = function () {
		
		var reqData = {
			idClient: $scope.student.idClient
		}
		$scope.progress = true;
		if( $rootScope.NetworkTrue ){  
			$AjaxQuery.post('removePhotoClient', reqData ).success(function(data) {
				$scope.progress = false;
				$scope.student.photo = "";
			}) 
		}else{
			alert('Pas de connexion');
		}
	}

	$scope.sendPhoto = function() {
		var reqData = {
			idClient: $scope.student.idClient,
			photo: $scope.student.photo
		}
		$scope.progress = true;
		if( $rootScope.NetworkTrue ){  
			$AjaxQuery.post('addphotoClient', reqData ).success(function(data) {
				$scope.progress = false;
			}) 
		}else{
			alert('Pas de connexion');
		}
	}
}])



.controller('massarCtrl', ['$scope', '$stateParams', 
function ($scope, $stateParams) {
	$scope.gotoMassar = function () {
		window.open("https://moutamadris.men.gov.ma/Ar/EspacePrive/Pages/Accueil.aspx", "_system")
	}
}])











.controller('bugCtrl', ['$scope','$rootScope', '$stateParams','$AjaxQuery','$alert', '$loader', 
function ($scope,$rootScope, $stateParams, $AjaxQuery, $alert, $loader) { 
	$scope.sendRapport = function sendRapport() {

		if( $scope.contentBug != '' ){ 
			var reqData = {
				content : $scope.contentBug,
		        from : 'parent',
		        idFrom : localStorage.getItem('idClient')
			}
			if( $rootScope.NetworkTrue ){  
				$loader(true); 
				$AjaxQuery.post('addProbleme', reqData ).success(function(data) {
					$loader(false);
					if( data == "true" ){  
			             $alert.success('Merci. Vos commentaires nous aideront à améliorer TawassolApp.',3000);
			             $scope.contentBug = '';
			        }else{ 
			            $alert.error('Erreur, éssayer plus tard')
			        } 
				})
			}else{
				alert( "Pas de connexion internet" );
			}
		}
	} 

}]); 






function verified() {
	if( localStorage.getItem('state') == 'true' ) return true;
	else return false;
}